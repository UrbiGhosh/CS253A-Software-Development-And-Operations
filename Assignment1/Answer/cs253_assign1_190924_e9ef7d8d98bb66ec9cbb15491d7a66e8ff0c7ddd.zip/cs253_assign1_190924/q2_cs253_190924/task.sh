#!/bin/bash
./10ZmoZg3pWmw9aA < a.txt & 
./DFwAU7iSoYorHy8 < b.txt &
./dUkeKOpRSOxQfx2 < c.txt &
